// Sample data for tasks and chat messages
const tasks = [];
const chatMessages = [];

// Function to display tasks
function displayTasks() {
    const tasksList = document.getElementById("tasks");
    tasksList.innerHTML = "";

    tasks.forEach(task => {
        const taskItem = document.createElement("li");
        taskItem.textContent = task;
        tasksList.appendChild(taskItem);
    });
}

// Function to display chat messages
function displayChatMessages() {
    const chatBox = document.getElementById("chat-box");
    chatBox.innerHTML = "";

    chatMessages.forEach(message => {
        const messageDiv = document.createElement("div");
        messageDiv.textContent = message;
        chatBox.appendChild(messageDiv);
    });
}

// Event listener for assigning tasks
document.getElementById("assign-button").addEventListener("click", () => {
    const assignTaskInput = document.getElementById("assign-task");
    const taskText = assignTaskInput.value.trim();
    if (taskText !== "") {
        tasks.push(taskText);
        assignTaskInput.value = "";
        displayTasks();
    }
});

// Event listener for sending chat messages
document.getElementById("send-message").addEventListener("click", () => {
    const userMessageInput = document.getElementById("user-message");
    const messageText = userMessageInput.value.trim();
    if (messageText !== "") {
        chatMessages.push(messageText);
        userMessageInput.value = "";
        displayChatMessages();
    }
});

// Initial display
displayTasks();
displayChatMessages();
